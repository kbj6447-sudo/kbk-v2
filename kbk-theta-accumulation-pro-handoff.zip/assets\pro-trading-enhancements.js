const PRO_ROUTES = {
  "/backtest": "backtest-panel",
  "/ai-analysis": "debug-panel",
};

function ready(fn) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", fn, { once: true });
  } else {
    fn();
  }
}

function money(n) {
  const value = Number(n);
  if (!Number.isFinite(value)) return "-";
  return value >= 10 ? `$${value.toFixed(2)}` : `$${value.toFixed(4)}`;
}

function pct(n) {
  const value = Number(n);
  if (!Number.isFinite(value)) return "-";
  return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
}

function compact(n) {
  const value = Number(n);
  if (!Number.isFinite(value)) return "-";
  if (Math.abs(value) >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(1)}B`;
  if (Math.abs(value) >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (Math.abs(value) >= 1_000) return `${Math.round(value / 1_000)}K`;
  return String(Math.round(value));
}

function textEscape(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]);
}

function patchFloatingPointText(root = document.body) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const node of nodes) {
    const before = node.nodeValue;
    if (!before || !/\d+\.\d{3,}점/.test(before)) continue;
    node.nodeValue = before.replace(/(\d+\.\d{3,})점/g, (_, raw) => {
      const value = Number(raw);
      return Number.isFinite(value) ? `${Math.round(value)}점` : `${raw}점`;
    });
  }
}

function ensureStyles() {
  if (document.getElementById("kbk-pro-trading-style")) return;
  const style = document.createElement("style");
  style.id = "kbk-pro-trading-style";
  style.textContent = `
    .topbar{padding:16px 20px!important;border-radius:18px!important;align-items:center!important}
    .brand-block h1{font-size:clamp(1.45rem,2.2vw,2.25rem)!important;margin:4px 0 6px!important;letter-spacing:0!important}
    .summary{font-size:.92rem!important;max-width:88ch!important}
    .disclaimer-pill{padding:9px 12px!important;border-radius:14px!important;font-size:.82rem!important}
    .menu-bar{margin:12px 0 14px!important;gap:8px!important}
    .menu-link{padding:9px 13px!important;border-radius:12px!important;font-size:.92rem!important}
    .accumulation-hero{padding:18px!important;border-radius:18px!important;grid-template-columns:minmax(0,1.3fr) minmax(280px,.7fr)!important}
    .accumulation-hero h2{font-size:clamp(1.35rem,2.2vw,2.1rem)!important;margin:4px 0 8px!important}
    .score-card{border-radius:12px!important;padding:12px 14px!important}
    .score-card strong{font-size:1.12rem!important}
    .toolbar{align-items:center!important;gap:10px!important}
    .search-box input,.holdings-form input{border-radius:10px!important;padding:11px 12px!important}
    .filter-chip{border-radius:12px!important;padding:10px 13px!important}
    .weight-guide{grid-template-columns:repeat(5,minmax(130px,1fr))!important;gap:8px!important}
    .weight-guide div{border-radius:12px!important;padding:12px 14px!important}
    .stock-grid{grid-template-columns:repeat(3,minmax(260px,1fr))!important;gap:10px!important}
    .stock-card{border-radius:14px!important;padding:14px!important;box-shadow:0 10px 28px rgba(15,23,42,.08)!important}
    .ticker-row h3{font-size:1.28rem!important}
    .company-name,.stock-note{font-size:.86rem!important;margin-top:7px!important}
    .price-row{gap:8px!important;margin-top:10px!important;font-size:.86rem!important}
    .score-number{font-size:2.1rem!important}
    .signal-box{min-width:86px!important}
    .metric-grid,.score-copy-grid,.forecast-grid{gap:8px!important;margin-top:12px!important}
    .metric-grid div,.score-copy-grid div,.forecast-card{border-radius:12px!important;padding:10px 12px!important}
    .reason-strip{margin-top:12px!important}
    .reason-chip,.type-chip,.accent-badge,.signal-tag{font-size:.72rem!important;padding:5px 8px!important}
    .kbk-empty-note{background:#fff7ed;border:1px solid rgba(249,115,22,.24);border-radius:14px;padding:14px 16px;color:#7c2d12;line-height:1.55}
    .kbk-route-note{background:#eff6ff;border:1px solid rgba(37,99,235,.22);border-radius:14px;padding:12px 14px;margin-bottom:12px;color:#1e3a8a;font-weight:800}
    .kbk-pro-refresh{position:fixed;right:18px;bottom:18px;z-index:50;border:0;border-radius:999px;background:#0f172a;color:#fff;padding:12px 16px;font-weight:900;box-shadow:0 12px 30px rgba(15,23,42,.24)}
    .kbk-pro-chart{background:#fff;border:1px solid rgba(15,23,42,.12);border-radius:12px;padding:12px;margin:12px 14px 0;box-shadow:0 10px 24px rgba(15,23,42,.08)}
    .kbk-pro-chart-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:8px}
    .kbk-pro-chart-head strong{display:block;color:#0f172a}
    .kbk-pro-chart-head span{display:block;color:#64748b;font-size:.78rem;margin-top:2px}
    .kbk-pro-chart svg{width:100%;height:auto;display:block}
    .kbk-pro-chart .axis{stroke:#e2e8f0;stroke-width:1}
    .kbk-pro-chart .wick{stroke-width:1.2}
    .kbk-pro-chart .up{stroke:#059669;fill:#10b981}
    .kbk-pro-chart .down{stroke:#dc2626;fill:#ef4444}
    .kbk-pro-chart .vwap{stroke:#2563eb;stroke-width:1.5;stroke-dasharray:5 4;fill:none}
    .kbk-pro-chart .level{stroke:#f59e0b;stroke-width:1.2;stroke-dasharray:4 4}
    .kbk-pro-chart .label{fill:#64748b;font-size:10px;font-weight:800}
    .kbk-pro-basis{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:10px 14px 0}
    .kbk-pro-basis div{background:#f8fafc;border:1px solid rgba(15,23,42,.08);border-radius:10px;padding:10px}
    .kbk-pro-basis span{display:block;color:#64748b;font-size:.76rem;font-weight:800}
    .kbk-pro-basis b{display:block;color:#0f172a;margin-top:4px}
    .kbk-pro-basis small{display:block;color:#64748b;margin-top:4px;line-height:1.35}
    .kbk-pro-alert-box{background:#ecfeff;border:1px solid rgba(14,116,144,.24);border-radius:12px;padding:12px 14px;color:#155e75;margin:12px 0;font-weight:800;line-height:1.5}
    #kbk-pro-top-picks{display:grid;gap:12px}
    .kbk-pro-top-card{background:#fff;border:1px solid rgba(15,23,42,.12);border-radius:12px;padding:13px;display:grid;gap:9px;box-shadow:0 10px 28px rgba(15,23,42,.08)}
    .kbk-pro-top-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
    .kbk-pro-top-head h3{margin:0;font-size:1.25rem;color:#0f172a}
    .kbk-pro-top-head p{margin:4px 0 0;color:#475569;font-size:.86rem}
    .kbk-pro-top-score{font-size:2rem;font-weight:950;color:#0f172a;line-height:1;text-align:right}
    .kbk-pro-top-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
    .kbk-pro-top-grid div{background:#f8fafc;border-radius:10px;padding:9px}
    .kbk-pro-top-grid span{display:block;color:#64748b;font-size:.76rem}
    .kbk-pro-top-grid b{display:block;margin-top:4px;color:#0f172a}
    @media (max-width:1100px){
      .accumulation-hero{grid-template-columns:1fr!important}
      .stock-grid{grid-template-columns:repeat(2,minmax(240px,1fr))!important}
      .weight-guide{grid-template-columns:repeat(2,minmax(0,1fr))!important}
    }
    @media (max-width:760px){
      .app-shell{padding:10px!important}
      .topbar{display:grid!important;padding:12px!important}
      .brand-block h1{font-size:1.28rem!important}
      .summary,.disclaimer-pill{font-size:.78rem!important}
      .stock-grid,.weight-guide,.hero-scoreboard,.metric-grid{grid-template-columns:1fr!important}
      .terminal-layout{grid-template-columns:1fr!important}
      .candidate-table,.signal-table,.debug-table{min-width:760px!important}
      .kbk-pro-top-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
      .kbk-pro-basis{grid-template-columns:1fr}
    }
  `;
  document.head.appendChild(style);
}

function addRefreshShortcut() {
  if (!document.getElementById("kbk-pro-refresh")) {
    const button = document.createElement("button");
    button.id = "kbk-pro-refresh";
    button.className = "kbk-pro-refresh";
    button.type = "button";
    button.textContent = "새로고침 R";
    button.addEventListener("click", () => refreshCurrentView());
    document.body.appendChild(button);
  }
  window.addEventListener("keydown", (event) => {
    if (event.key.toLowerCase() !== "r") return;
    const tag = document.activeElement?.tagName?.toLowerCase();
    if (tag === "input" || tag === "textarea") return;
    event.preventDefault();
    refreshCurrentView();
  });
}

function refreshCurrentView() {
  const visibleRefresh = Array.from(document.querySelectorAll("button"))
    .find((button) => /새로고침|감시 갱신|전체 분석/.test(button.textContent || "") && button.offsetParent);
  if (visibleRefresh) {
    visibleRefresh.click();
    return;
  }
  window.location.reload();
}

function ensureRouteLinks() {
  const menu = document.querySelector(".menu-bar");
  if (!menu) return;

  const configs = [
    { label: "백테스트", path: "/backtest", target: "backtest-panel" },
    { label: "AI 분석", path: "/ai-analysis", target: "debug-panel" },
    { label: "통합 최종 후보", path: "/top-picks", target: "kbk-pro-top-picks" },
  ];

  for (const config of configs) {
    let node = Array.from(menu.querySelectorAll(".menu-link"))
      .find((item) => item.textContent?.trim() === config.label);
    if (!node) {
      node = document.createElement("button");
      node.type = "button";
      node.className = "menu-link menu-button";
      node.textContent = config.label;
      menu.appendChild(node);
    }
    node.addEventListener("click", (event) => {
      event.preventDefault();
      history.pushState({}, "", config.path);
      handleRoute();
    });
  }
}

function showAllPanels() {
  document.querySelectorAll(".page-stack > .page-panel").forEach((panel) => {
    panel.style.display = "";
  });
  const top = document.getElementById("kbk-pro-top-picks");
  if (top) top.remove();
}

function routeScroll(targetId, message) {
  showAllPanels();
  const target = document.getElementById(targetId);
  if (!target) return;
  if (!target.previousElementSibling?.classList?.contains("kbk-route-note")) {
    const note = document.createElement("div");
    note.className = "kbk-route-note";
    note.textContent = message;
    target.parentElement?.insertBefore(note, target);
  }
  window.setTimeout(() => target.scrollIntoView({ block: "start", behavior: "smooth" }), 120);
  if (targetId === "backtest-panel") window.setTimeout(renderBacktestExpectation, 300);
}

async function renderTopPicks() {
  const stack = document.querySelector(".page-stack");
  if (!stack) return;
  document.querySelectorAll(".page-stack > .page-panel").forEach((panel) => {
    panel.style.display = "none";
  });
  let panel = document.getElementById("kbk-pro-top-picks");
  if (!panel) {
    panel = document.createElement("section");
    panel.id = "kbk-pro-top-picks";
    stack.prepend(panel);
  }
  panel.innerHTML = `<section class="kbk-route-note">통합 최종 후보를 계산하는 중입니다.</section>`;
  try {
    const payload = await fetch("/api/scanner", { cache: "no-store" }).then((res) => res.json());
    const items = (payload?.data?.items || [])
      .filter((item) => item?.symbol && item.included !== false)
      .map((item) => {
        const price = Number(item.price ?? item.preMarketPrice ?? 0);
        const change = Number(item.changePercent ?? item.preMarketChangePercent ?? 0);
        const volume = Number(item.volume ?? item.preMarketVolume ?? 0);
        const surge = Math.round(Number(item.finalProbabilityScore ?? item.scannerScore ?? 0));
        const risk = Math.round(Number(item.riskScore ?? 50));
        const pattern = Math.round(Number(item.patternSimilarityScore ?? 50));
        const finalScore = Math.round(Math.max(0, Math.min(100, surge * .55 + pattern * .2 + (volume >= 5_000_000 ? 14 : volume >= 1_000_000 ? 8 : 0) + (change >= 20 ? 8 : 0) - risk * .12)));
        return { item, price, change, volume, surge, risk, pattern, finalScore };
      })
      .filter((pick) => pick.finalScore >= 62)
      .sort((a, b) => b.finalScore - a.finalScore)
      .slice(0, 10);
    panel.innerHTML = `
      <section class="accumulation-hero">
        <div>
          <p class="section-kicker">Integrated Picks</p>
          <h2>통합 최종 후보</h2>
          <p class="section-copy">실시간 단타 후보, 폭등 감시, 매집/패턴 점수를 함께 보고 과열 위험을 감점한 실전용 우선순위입니다.</p>
        </div>
        <div class="hero-scoreboard">
          <div class="score-card"><span>후보</span><strong>${items.length}</strong></div>
          <div class="score-card"><span>기준</span><strong>62점 이상</strong></div>
        </div>
      </section>
      ${items.length ? items.map(({ item, price, change, volume, surge, risk, pattern, finalScore }) => `
        <article class="kbk-pro-top-card">
          <div class="kbk-pro-top-head">
            <div><h3>${textEscape(item.symbol)}</h3><p>${textEscape(item.name || item.symbol)}</p></div>
            <div class="kbk-pro-top-score">${finalScore}</div>
          </div>
          <div class="price-row">
            <strong>${money(price)}</strong>
            <span>${pct(change)}</span>
            <span>거래량 ${compact(volume)}</span>
          </div>
          <div class="kbk-pro-top-grid">
            <div><span>폭등 감시</span><b>${surge}점</b></div>
            <div><span>패턴</span><b>${pattern}점</b></div>
            <div><span>위험</span><b>${risk}점</b></div>
            <div><span>통합</span><b>${finalScore}점</b></div>
          </div>
        </article>
      `).join("") : `<section class="kbk-empty-note">현재 통합 기준을 통과한 후보가 없습니다. 새로고침으로 다시 확인해 주세요.</section>`}
    `;
  } catch (error) {
    panel.innerHTML = `<section class="kbk-empty-note">통합 후보 계산에 실패했습니다: ${textEscape(error.message)}</section>`;
  }
}

function handleRoute() {
  const path = window.location.pathname;
  if (path === "/top-picks") {
    renderTopPicks();
    return;
  }
  if (path === "/backtest") {
    routeScroll("backtest-panel", "백테스트 화면입니다. 선택 종목 또는 전체 분석 버튼으로 시그널 이후 움직임을 확인합니다.");
    return;
  }
  if (path === "/ai-analysis") {
    routeScroll("debug-panel", "AI 분석 화면입니다. 후보 선정 근거와 계산 데이터를 확인합니다.");
    return;
  }
  if (!PRO_ROUTES[path]) showAllPanels();
}

function clarifyEmptyAccumulation() {
  if (!/\/scanner\/accumulation|\/accumulation/.test(location.pathname)) return;
  const hero = document.querySelector(".accumulation-hero");
  if (!hero || document.getElementById("kbk-accumulation-empty-note")) return;
  const counts = Array.from(hero.querySelectorAll(".score-card strong")).map((node) => Number((node.textContent || "").replace(/\D/g, "")));
  if (!counts.length || counts.some((value) => value > 0)) return;
  const note = document.createElement("section");
  note.id = "kbk-accumulation-empty-note";
  note.className = "kbk-empty-note";
  note.textContent = "현재 조건을 통과한 매집/급등 직전/횡보 돌파 후보가 없습니다. 데이터 로딩 오류가 아니라, 지금 시점의 필터를 만족한 종목이 없다는 뜻입니다.";
  hero.insertAdjacentElement("afterend", note);
}

function toNumber(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

async function fetchJson(url) {
  const response = await fetch(url, { cache: "no-store" });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.ok === false) throw new Error(payload?.message || `API ${response.status}`);
  return payload.data || payload;
}

function normalizeBars(payload) {
  const bars = payload?.bars || payload?.data?.bars || payload?.candles || [];
  return bars.map((bar) => {
    const close = toNumber(bar.close ?? bar.c ?? bar.price);
    return {
      time: bar.time || bar.date || bar.timestamp || "",
      open: toNumber(bar.open ?? bar.o) ?? close,
      high: toNumber(bar.high ?? bar.h) ?? close,
      low: toNumber(bar.low ?? bar.l) ?? close,
      close,
      volume: toNumber(bar.volume ?? bar.v) ?? 0,
    };
  }).filter((bar) => bar.close !== null && bar.high !== null && bar.low !== null).slice(-60);
}

function calculateVwap(bars) {
  let pv = 0;
  let volume = 0;
  return bars.map((bar) => {
    const typical = (bar.high + bar.low + bar.close) / 3;
    pv += typical * bar.volume;
    volume += bar.volume;
    return volume > 0 ? pv / volume : null;
  });
}

function calculateAtr(bars, period = 14) {
  const ranges = [];
  for (let i = 0; i < bars.length; i += 1) {
    const prevClose = i ? bars[i - 1].close : bars[i].close;
    ranges.push(Math.max(
      bars[i].high - bars[i].low,
      Math.abs(bars[i].high - prevClose),
      Math.abs(bars[i].low - prevClose),
    ));
  }
  const recent = ranges.slice(-period);
  if (!recent.length) return null;
  return recent.reduce((sum, value) => sum + value, 0) / recent.length;
}

function selectedSymbolFromMonitor() {
  const text = document.getElementById("monitor-summary")?.textContent || "";
  const match = text.match(/\b[A-Z][A-Z0-9.-]{0,10}\b/);
  return match?.[0] || document.querySelector(".candidate-table tr.selected b")?.textContent?.trim() || null;
}

function currentUsdKrw() {
  const match = document.body.textContent.match(/USD\/KRW\s*([\d,]+)/);
  const parsed = match ? Number(match[1].replace(/,/g, "")) : null;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function krwMoneyFromUsd(usd) {
  const rate = currentUsdKrw();
  const value = Number(usd);
  if (!Number.isFinite(value) || !rate) return "-";
  return `${Math.round(value * rate).toLocaleString("ko-KR")}원`;
}

function syncMonitorPriceBadge(symbol, price) {
  const summary = document.getElementById("monitor-summary");
  const value = Number(price);
  if (!summary || !symbol || !Number.isFinite(value)) return;
  const label = `실시간 분봉 ${money(value)} / ${krwMoneyFromUsd(value)} · ${new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`;
  const candidates = Array.from(summary.querySelectorAll("*")).filter((node) =>
    node.children.length === 0 && /실시간 분봉/.test(node.textContent || "")
  );
  for (const node of candidates) node.textContent = label;
}

function candleChartSvg(bars, currentPrice, levels) {
  const width = 760;
  const height = 280;
  const pad = 26;
  const values = bars.flatMap((bar) => [bar.high, bar.low]);
  for (const value of Object.values(levels)) if (Number.isFinite(value)) values.push(value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = Math.max(max - min, 0.0001);
  const x = (index) => pad + index * ((width - pad * 2) / Math.max(bars.length - 1, 1));
  const y = (value) => height - pad - ((value - min) / span) * (height - pad * 2);
  const candleWidth = Math.max(3, Math.min(9, (width - pad * 2) / Math.max(bars.length, 1) * 0.58));
  const vwaps = calculateVwap(bars);
  const vwapPath = vwaps.map((value, index) => value ? `${index ? "L" : "M"}${x(index).toFixed(1)} ${y(value).toFixed(1)}` : "").join(" ");
  const candles = bars.map((bar, index) => {
    const up = bar.close >= bar.open;
    const cx = x(index);
    const openY = y(bar.open);
    const closeY = y(bar.close);
    const highY = y(bar.high);
    const lowY = y(bar.low);
    const bodyY = Math.min(openY, closeY);
    const bodyH = Math.max(Math.abs(openY - closeY), 2);
    const cls = up ? "up" : "down";
    return `<line class="wick ${cls}" x1="${cx.toFixed(1)}" x2="${cx.toFixed(1)}" y1="${highY.toFixed(1)}" y2="${lowY.toFixed(1)}"></line><rect class="${cls}" x="${(cx - candleWidth / 2).toFixed(1)}" y="${bodyY.toFixed(1)}" width="${candleWidth.toFixed(1)}" height="${bodyH.toFixed(1)}" rx="1"></rect>`;
  }).join("");
  const levelLines = Object.entries(levels).filter(([, value]) => Number.isFinite(value)).map(([label, value], index) => {
    const yy = y(value);
    return `<line class="level" x1="${pad}" x2="${width - pad}" y1="${yy.toFixed(1)}" y2="${yy.toFixed(1)}"></line><text class="label" x="${pad + 4}" y="${(yy - 4 - index % 2 * 10).toFixed(1)}">${label} ${money(value)}</text>`;
  }).join("");
  const last = bars.at(-1)?.close ?? currentPrice;
  return `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="자체 캔들차트">
    <line class="axis" x1="${pad}" x2="${width - pad}" y1="${height - pad}" y2="${height - pad}"></line>
    <line class="axis" x1="${pad}" x2="${pad}" y1="${pad}" y2="${height - pad}"></line>
    ${levelLines}
    ${vwapPath.trim() ? `<path class="vwap" d="${vwapPath}"></path>` : ""}
    ${candles}
    <text class="label" x="${width - pad - 120}" y="${pad + 12}">현재 ${money(last)}</text>
  </svg>`;
}

async function enhanceMonitorPanel() {
  const panel = document.getElementById("monitor-panel");
  const symbol = selectedSymbolFromMonitor();
  if (!panel || !symbol || panel.dataset.proSymbol === symbol) return;
  panel.dataset.proSymbol = symbol;
  try {
    const from = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
    const [quote, history] = await Promise.all([
      fetchJson(`/api/quote?symbol=${encodeURIComponent(symbol)}`).catch(() => null),
      fetchJson(`/api/history?symbol=${encodeURIComponent(symbol)}&from=${encodeURIComponent(from)}`),
    ]);
    const bars = normalizeBars(history);
    if (!bars.length) return;
    const price = toNumber(quote?.price ?? quote?.preMarketPrice) ?? bars.at(-1).close;
    syncMonitorPriceBadge(symbol, price);
    const atr = calculateAtr(bars);
    const recentHigh = Math.max(...bars.slice(-20).map((bar) => bar.high));
    const recentLow = Math.min(...bars.slice(-20).map((bar) => bar.low));
    const vwap = calculateVwap(bars).filter(Boolean).at(-1);
    const entryLow = Math.max(vwap || price * .995, recentHigh * .995);
    const entryHigh = Math.max(recentHigh * 1.006, price * 1.003);
    const atrStop = atr ? Math.min(recentLow * .998, price - atr * 1.4) : recentLow * .998;
    const stopPct = price ? ((atrStop - price) / price) * 100 : null;
    const chart = document.createElement("section");
    chart.className = "kbk-pro-chart";
    chart.innerHTML = `
      <div class="kbk-pro-chart-head">
        <div><strong>${textEscape(symbol)} 자체 캔들차트</strong><span>최근 분봉 기준, VWAP 파란 점선 / 진입·손절 기준선 표시</span></div>
        <span>${new Date().toLocaleTimeString("ko-KR")}</span>
      </div>
      ${candleChartSvg(bars, price, { VWAP: vwap, 진입: entryLow, 손절: atrStop })}
    `;
    const basis = document.createElement("section");
    basis.className = "kbk-pro-basis";
    basis.innerHTML = `
      <div><span>진입가 계산 근거</span><b>${money(entryLow)} ~ ${money(entryHigh)}</b><small>VWAP 위 유지 + 최근 20개 분봉 고점 돌파권을 기준으로 계산했습니다.</small></div>
      <div><span>ATR 기반 손절</span><b>${money(atrStop)} ${stopPct !== null ? `(${pct(stopPct)})` : ""}</b><small>최근 14개 분봉 ATR ${atr ? money(atr) : "-"}와 직전 지지선을 함께 반영했습니다.</small></div>
      <div><span>검증 포인트</span><b>VWAP / 거래량 / 고점 돌파</b><small>현재가가 VWAP 아래로 내려가거나 돌파 거래량이 약하면 신규 진입을 보류합니다.</small></div>
    `;
    panel.querySelector(".kbk-pro-chart")?.remove();
    panel.querySelector(".kbk-pro-basis")?.remove();
    panel.prepend(basis);
    panel.prepend(chart);
  } catch {
    panel.dataset.proSymbol = "";
  }
}

async function renderBacktestExpectation() {
  const target = document.getElementById("backtest-panel");
  if (!target || document.getElementById("kbk-pro-expectancy")) return;
  const box = document.createElement("section");
  box.id = "kbk-pro-expectancy";
  box.className = "kbk-pro-alert-box";
  box.textContent = "승률/기대값 통계를 계산하는 중입니다.";
  target.prepend(box);
  try {
    const payload = await fetchJson("/api/scanner");
    const items = (payload.items || []).filter((item) => item?.included !== false);
    const sample = items.slice(0, 80);
    const high = sample.filter((item) => Number(item.finalProbabilityScore ?? item.scannerScore ?? 0) >= 75);
    const avgScore = sample.reduce((sum, item) => sum + Number(item.finalProbabilityScore ?? item.scannerScore ?? 0), 0) / Math.max(sample.length, 1);
    const avgMove = sample.reduce((sum, item) => sum + Number(item.changePercent ?? item.preMarketChangePercent ?? 0), 0) / Math.max(sample.length, 1);
    const risk = sample.reduce((sum, item) => sum + Number(item.riskScore ?? 50), 0) / Math.max(sample.length, 1);
    box.innerHTML = `
      <strong>현재 후보군 기대값 요약</strong><br>
      표본 ${sample.length}개 · 75점 이상 ${high.length}개 · 평균 점수 ${Math.round(avgScore)}점 · 평균 상승률 ${pct(avgMove)} · 평균 위험 ${Math.round(risk)}점<br>
      실제 승률은 아래 시그널 기록이 쌓일수록 백테스트 테이블에서 검증됩니다. 지금 표시는 현재 후보군의 조건 강도 요약입니다.
    `;
  } catch (error) {
    box.textContent = `승률/기대값 통계 계산 실패: ${error.message}`;
  }
}

function boot() {
  ensureStyles();
  addRefreshShortcut();
  ensureRouteLinks();
  handleRoute();
  clarifyEmptyAccumulation();
  patchFloatingPointText();

  const observer = new MutationObserver(() => {
    patchFloatingPointText();
    ensureRouteLinks();
    clarifyEmptyAccumulation();
    enhanceMonitorPanel();
  });
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  window.addEventListener("popstate", handleRoute);
}

ready(() => window.setTimeout(boot, 250));
