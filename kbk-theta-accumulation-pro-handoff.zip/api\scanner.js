const UPSTREAM = "https://kbk-theta.vercel.app/api/scanner";

function num(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, value));
}

function volumeStrength(item) {
  const rawVolume = Math.max(num(item.volume) ?? 0, num(item.preMarketVolume) ?? 0);
  const relativeVolume = num(item.relativeVolume) ?? num(item.volumeRatio) ?? 1;
  const rvolScore = relativeVolume >= 8 ? 96
    : relativeVolume >= 5 ? 86
      : relativeVolume >= 3 ? 74
        : relativeVolume >= 1.5 ? 60
          : 42;
  const rawScore = rawVolume >= 20_000_000 ? 96
    : rawVolume >= 10_000_000 ? 86
      : rawVolume >= 5_000_000 ? 78
        : rawVolume >= 1_000_000 ? 65
          : 42;
  return clamp(Math.max(rvolScore, rawScore));
}

function boostedScore(item) {
  const premarketChange = num(item.preMarketChangePercent) ?? num(item.changePercent) ?? 0;
  const rawVolume = Math.max(num(item.volume) ?? 0, num(item.preMarketVolume) ?? 0);
  const currentScore = num(item.finalProbabilityScore) ?? num(item.scannerScore) ?? 0;

  let score = currentScore;
  if (premarketChange >= 150 && rawVolume >= 1_000_000) score = Math.max(score, 82);
  if (premarketChange >= 100 && rawVolume >= 5_000_000) score = Math.max(score, 78);
  if (premarketChange >= 60 && rawVolume >= 5_000_000) score = Math.max(score, 70);

  return Math.round(clamp(score));
}

function normalizeItem(item) {
  if (!item || typeof item !== "object") return item;

  const boosted = boostedScore(item);
  const rawVolume = Math.max(num(item.volume) ?? 0, num(item.preMarketVolume) ?? 0);
  const volumeScore = volumeStrength(item);

  return {
    ...item,
    volume: rawVolume || item.volume,
    volumeStrengthScore: volumeScore,
    scannerScore: Math.max(num(item.scannerScore) ?? 0, boosted),
    finalProbabilityScore: Math.max(num(item.finalProbabilityScore) ?? 0, boosted),
    selectionReasons: [
      ...(Array.isArray(item.selectionReasons) ? item.selectionReasons : []),
      boosted > (num(item.finalProbabilityScore) ?? 0) ? "Premarket surge volume boost" : null,
    ].filter(Boolean),
  };
}

module.exports = async function handler(req, res) {
  try {
    const upstreamUrl = new URL(UPSTREAM);
    const requestUrl = new URL(req.url, "https://kbk-theta-accumulation.vercel.app");
    upstreamUrl.search = requestUrl.search;

    const response = await fetch(upstreamUrl, {
      headers: { accept: "application/json" },
    });
    const payload = await response.json();

    if (payload?.data?.items && Array.isArray(payload.data.items)) {
      payload.data.items = payload.data.items
        .map(normalizeItem)
        .sort((a, b) => (num(b.finalProbabilityScore) ?? 0) - (num(a.finalProbabilityScore) ?? 0));
    }

    res.setHeader("cache-control", "no-store");
    res.status(response.status).json(payload);
  } catch (error) {
    res.status(502).json({
      ok: false,
      message: error instanceof Error ? error.message : "scanner proxy failed",
    });
  }
};
